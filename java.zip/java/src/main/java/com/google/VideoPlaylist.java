package com.google;

/** A class used to represent a Playlist */
class VideoPlaylist {

}
